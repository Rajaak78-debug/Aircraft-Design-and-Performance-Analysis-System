# Aircraft Design & Performance Analysis System

An interactive Python and Streamlit application for preliminary aircraft aerodynamic analysis, design comparison, design-space optimization, flight-performance estimation, 3D geometry visualization, and PDF report generation.

**Internship context:** Def-Space Autumn Internship 2026  
**Developer:** MD Rajaak

## Overview

The application brings several preliminary aircraft-engineering calculations into one interactive dashboard. Users can enter aircraft parameters, inspect calculated performance, compare two configurations, explore candidate wing designs, estimate selected flight-performance quantities, visualize simplified aircraft geometry, and export analysis results.

## Modules

1. **Basic Aircraft Performance Analysis** — calculates aircraft weight, dynamic pressure, lift, drag, wing loading, aspect ratio, stall velocity, and lift-to-drag ratio.
2. **Advanced Aerodynamic Analysis** — estimates the lift coefficient required for steady level flight, induced and total drag coefficients, drag, lift-to-drag ratio, power required, and a stall/level-flight validity flag using a parabolic drag-polar model.
3. **Aircraft Design Comparison** — compares two aircraft configurations under common operating conditions, including stall speed, wing loading, aerodynamic efficiency, drag, and power metrics.
4. **Aircraft Design Optimization** — evaluates a grid of wing-area and wingspan combinations and identifies candidates for minimum drag, maximum lift-to-drag ratio, and minimum power, subject to the model's operating-speed stall constraint.
5. **Flight Performance Analysis** — provides preliminary estimates for take-off, landing, climb, range, and endurance, plus speed-dependent and altitude-dependent data.
6. **Aircraft Geometry & 3D Visualization** — calculates aspect ratio, root chord, tip chord, and mean aerodynamic chord, and renders a simplified interactive 3D aircraft geometry model.
7. **Engineering Report Generator** — exports basic and advanced aircraft-performance results to a PDF report.

## Technology Stack

- Python
- Streamlit
- NumPy
- Pandas
- Matplotlib
- Plotly
- ReportLab

## Project Structure

```text
Aircraft-Design-and-Performance-Analysis-System/
├── app.py
├── calculations.py
├── comparison.py
├── flight_analysis.py
├── geometry.py
├── optimization.py
├── report_generator.py
├── visualization.py
├── requirements.txt
├── README.md
├── .gitignore
└── reports/
    └── aircraft_performance_report.pdf
```

## Installation

Python 3.10 or newer is recommended.

1. Clone this repository:

   ```bash
   git clone https://github.com/Rajaak78-debug/Aircraft-Design-and-Performance-Analysis-System.git
   cd Aircraft-Design-and-Performance-Analysis-System
   ```

2. Create a virtual environment:

   ```bash
   python -m venv venv
   ```

3. Activate it.

   **Windows PowerShell:**

   ```powershell
   .\venv\Scripts\Activate.ps1
   ```

   **macOS/Linux:**

   ```bash
   source venv/bin/activate
   ```

4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Start the dashboard:

   ```bash
   python -m streamlit run app.py
   ```

The local Streamlit URL is usually `http://localhost:8501`.

## Usage

1. Enter aircraft mass, wing area, wingspan, airspeed, air density, and aerodynamic coefficients in the sidebar.
2. Select **Analyze Aircraft** to run the basic and advanced analyses.
3. Scroll through Modules 3–6 to compare designs, explore optimization, run flight-performance estimates, and visualize aircraft geometry.
4. Use Module 7 to generate and download a PDF report of the saved basic and advanced analysis results.

## Sample Report

A sample generated report is included in `reports/aircraft_performance_report.pdf`. It demonstrates the report layout and a set of calculated basic and advanced performance values.

## Model Scope and Limitations

This is an educational and preliminary engineering analysis tool. It uses simplified aerodynamic relationships and assumptions, including steady level-flight calculations, a parabolic drag polar, constant aerodynamic efficiency factors, and simplified performance estimates. The 3D geometry is a conceptual visualization, not a manufacturing-ready CAD model.

The application is **not** a certified aircraft design tool, flight simulator, or substitute for validated engineering analysis. Its outputs must not be used as the basis for real aircraft construction, flight planning, or safety-critical decisions.

## Author

**MD Rajaak**  
B.Tech, Electronics and Communication Engineering  
Central University of Karnataka

## Acknowledgement

Developed in the context of the Def-Space Autumn Internship 2026.
